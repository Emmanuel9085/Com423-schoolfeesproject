<?php

require 'rand.php';


session_start();


$_SESSION['captcha_id'] = $str;

?>