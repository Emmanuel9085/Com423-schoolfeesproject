﻿
            $("a.preview").prettyPhoto({
                social_tools: false
            });

            

            $('#port-folio').mixitup({
                targetSelector: '.portfolio-item',
                filterSelector: '.filter',
                effects: ['fade'],
                easing: 'snap',


            });

     